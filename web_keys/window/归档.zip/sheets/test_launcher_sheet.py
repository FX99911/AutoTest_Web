"""
测试启动sheet页

该模块提供了一个图形用户界面，用于启动测试执行，包括：
1. 选择要执行的测试用例文件
2. 配置测试执行参数
3. 启动测试执行
"""

import tkinter as tk
from tkinter import ttk, messagebox
import os
import subprocess
import threading
from web_keys.environment_info.montage_url import home


def get_xlsx_files_in_cases_date():
    """
    获取cases_date目录下所有的xlsx文件

    Returns:
        list: xlsx文件列表，如果目录不存在会先创建
    """
    cases_date_dir = os.path.join(home, 'cases_date')
    if not os.path.exists(cases_date_dir):
        os.makedirs(cases_date_dir, exist_ok=True)
        return []

    files = os.listdir(cases_date_dir)
    xlsx_files = [f for f in files if f.lower().endswith('.xlsx')]
    return xlsx_files


def create_test_launcher_sheet(parent_frame, widget_dict):
    """
    创建测试启动sheet页

    Args:
        parent_frame: 父框架对象
        widget_dict: 用于存储控件引用的字典

    Returns:
        dict: 更新后的widget_dict
    """
    # 创建主框架
    main_frame = ttk.Frame(parent_frame, padding="20")
    main_frame.pack(fill=tk.BOTH, expand=True)

    # 创建标题
    title_label = ttk.Label(main_frame, text="测试启动", font=("Arial", 16, "bold"))
    title_label.pack(anchor="center", pady=(0, 20))

    # 创建文件选择区域
    file_frame = ttk.LabelFrame(main_frame, text="选择测试用例文件", padding=(10, 5))
    file_frame.pack(fill="x", pady=(0, 15))

    # 创建列表框显示可用的测试用例文件
    list_frame = ttk.Frame(file_frame)
    list_frame.pack(fill="both", expand=True, pady=5)

    scrollbar = ttk.Scrollbar(list_frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set, height=10)
    listbox.pack(side=tk.LEFT, fill="both", expand=True)
    scrollbar.config(command=listbox.yview)

    # 填充列表框，显示当前已有的Excel文件
    xlsx_files = get_xlsx_files_in_cases_date()
    for file in xlsx_files:
        listbox.insert(tk.END, file)

    widget_dict['launcher_listbox'] = listbox

    # 添加刷新按钮
    def refresh_list():
        """
        刷新文件列表，显示cases_date目录下的最新文件
        """
        listbox.delete(0, tk.END)  # 清空列表
        xlsx_files = get_xlsx_files_in_cases_date()  # 重新获取文件列表
        for file in xlsx_files:
            listbox.insert(tk.END, file)  # 重新填充列表

    refresh_button = ttk.Button(file_frame, text="刷新列表", command=refresh_list)
    refresh_button.pack(pady=10)

    # 创建参数配置区域
    param_frame = ttk.LabelFrame(main_frame, text="测试参数配置", padding=(10, 5))
    param_frame.pack(fill="x", pady=(0, 15))

    # 添加参数配置选项
    options_frame = ttk.Frame(param_frame)
    options_frame.pack(fill="x", pady=5)

    # 添加-v选项（详细输出）
    verbose_var = tk.BooleanVar(value=True)
    verbose_check = ttk.Checkbutton(options_frame, text="-v (详细输出)", variable=verbose_var)
    verbose_check.pack(side=tk.LEFT, padx=10)

    # 添加-s选项（显示print输出）
    show_output_var = tk.BooleanVar(value=True)
    show_output_check = ttk.Checkbutton(options_frame, text="-s (显示print输出)", variable=show_output_var)
    show_output_check.pack(side=tk.LEFT, padx=10)

    # 添加--html选项（生成HTML报告）
    html_report_var = tk.BooleanVar(value=True)
    html_report_check = ttk.Checkbutton(options_frame, text="--html (生成HTML报告)", variable=html_report_var)
    html_report_check.pack(side=tk.LEFT, padx=10)

    # 创建执行区域
    execution_frame = ttk.LabelFrame(main_frame, text="执行测试", padding=(10, 5))
    execution_frame.pack(fill="x", pady=(0, 15))

    # 添加状态标签
    status_label = ttk.Label(execution_frame, text="就绪")
    status_label.pack(pady=5)

    # 添加输出文本框
    output_frame = ttk.Frame(execution_frame)
    output_frame.pack(fill="both", expand=True, pady=5)

    output_scrollbar = ttk.Scrollbar(output_frame)
    output_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    output_text = tk.Text(output_frame, yscrollcommand=output_scrollbar.set, height=10, wrap=tk.WORD)
    output_text.pack(side=tk.LEFT, fill="both", expand=True)
    output_scrollbar.config(command=output_text.yview)

    widget_dict['output_text'] = output_text
    widget_dict['status_label'] = status_label

    # 添加执行按钮
    def start_execution():
        """
        开始执行测试
        """
        selected_indices = listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("提示", "请先选择要执行的测试用例文件")
            return

        selected_index = selected_indices[0]
        file_name = listbox.get(selected_index)
        file_path = os.path.join(home, 'cases_date', file_name)

        # 更新状态标签
        status_label.config(text="正在执行...")
        output_text.delete(1.0, tk.END)
        output_text.insert(tk.END, f"开始执行测试用例: {file_name}\n\n")

        # 构建pytest命令
        cmd = ["pytest"]
        
        # 添加参数
        if verbose_var.get():
            cmd.append("-v")
        
        if show_output_var.get():
            cmd.append("-s")
        
        if html_report_var.get():
            report_path = os.path.join(home, 'reports', f"{os.path.splitext(file_name)[0]}_report.html")
            os.makedirs(os.path.dirname(report_path), exist_ok=True)
            cmd.extend(["--html", report_path])
        
        # 添加测试文件路径
        cmd.append(file_path)
        
        # 在新线程中执行命令，避免界面卡死
        def run_command():
            try:
                process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    universal_newlines=True
                )
                
                # 实时读取输出
                for line in process.stdout:
                    output_text.insert(tk.END, line)
                    output_text.see(tk.END)
                    output_text.update_idletasks()
                
                process.wait()
                
                # 更新状态标签
                if process.returncode == 0:
                    status_label.config(text="执行完成")
                    messagebox.showinfo("成功", f"测试用例 {file_name} 执行完成")
                else:
                    status_label.config(text="执行失败")
                    messagebox.showerror("错误", f"测试用例 {file_name} 执行失败")
            
            except Exception as e:
                # 更新状态标签
                status_label.config(text="执行失败")
                error_msg = f"执行测试用例时出错: {e}"
                output_text.insert(tk.END, f"\n{error_msg}\n")
                messagebox.showerror("错误", error_msg)
        
        # 启动线程
        threading.Thread(target=run_command, daemon=True).start()

    # 添加提交按钮区域
    submit_frame = ttk.Frame(main_frame)
    submit_frame.pack(fill="x", pady=20)

    # 执行按钮
    submit_button = ttk.Button(
        submit_frame,
        text="开始执行",
        command=start_execution,
        style="Accent.TButton",
        width=15
    )
    submit_button.pack(side=tk.LEFT, padx=10)

    # 取消按钮 - 清空选择
    cancel_button = ttk.Button(
        submit_frame,
        text="取消选择",
        command=lambda: listbox.selection_clear(0, tk.END),
        width=15
    )
    cancel_button.pack(side=tk.LEFT, padx=10)

    return widget_dict 