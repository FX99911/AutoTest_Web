"""
测试用例文件管理sheet页

该模块提供了一个图形用户界面，用于管理测试用例文件，包括：
1. 上传测试用例文件
2. 显示已上传的测试用例文件
3. 删除已上传的测试用例文件
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import shutil
from web_keys.environment_info.montage_url import home


def get_xlsx_files_in_cases_date():
    """
    获取cases_date目录下所有的xlsx文件

    Returns:
        list: xlsx文件列表，如果目录不存在会先创建
    """
    cases_date_dir = os.path.join(home, 'cases_date')
    if not os.path.exists(cases_date_dir):
        os.makedirs(cases_date_dir, exist_ok=True)
        return []

    files = os.listdir(cases_date_dir)
    xlsx_files = [f for f in files if f.lower().endswith('.xlsx')]
    return xlsx_files


def create_file_management_sheet(parent_frame, widget_dict):
    """
    创建文件管理sheet页

    Args:
        parent_frame: 父框架对象
        widget_dict: 用于存储控件引用的字典

    Returns:
        dict: 更新后的widget_dict
    """
    # 创建主框架
    main_frame = ttk.Frame(parent_frame, padding="20")
    main_frame.pack(fill=tk.BOTH, expand=True)

    # 创建标题
    title_label = ttk.Label(main_frame, text="测试用例文件管理", font=("Arial", 16, "bold"))
    title_label.pack(anchor="center", pady=(0, 20))

    # 创建左右两栏框架
    content_frame = ttk.Frame(main_frame)
    content_frame.pack(fill="both", expand=True)

    # 左侧框架：文件上传区域
    left_frame = ttk.LabelFrame(content_frame, text="上传测试用例文件", padding=(10, 5))
    left_frame.pack(side=tk.LEFT, fill="both", expand=True, padx=(0, 10))

    # 创建列表框显示已选择的文件
    files_list_frame = ttk.Frame(left_frame)
    files_list_frame.pack(fill="both", expand=True, pady=5)

    files_scrollbar = ttk.Scrollbar(files_list_frame)
    files_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    files_listbox = tk.Listbox(files_list_frame, yscrollcommand=files_scrollbar.set, height=15)
    files_listbox.pack(side=tk.LEFT, fill="both", expand=True)
    files_scrollbar.config(command=files_listbox.yview)

    widget_dict['selected_files'] = []  # 存储选择的文件路径列表
    widget_dict['files_listbox'] = files_listbox

    # 按钮区域 - 文件操作按钮
    file_buttons_frame = ttk.Frame(left_frame)
    file_buttons_frame.pack(fill="x", pady=10)

    def upload_files():
        """
        处理多文件上传功能，追加而不是替换已选择的文件
        """
        file_paths = filedialog.askopenfilenames(
            title="选择测试用例文件(可多选)",
            filetypes=[("Excel文件", "*.xlsx")]
        )
        if file_paths:
            # 添加新选择的文件（不清空之前的选择）
            for file_path in file_paths:
                # 验证文件格式
                if not file_path.lower().endswith('.xlsx'):
                    messagebox.showerror("格式错误", f"{os.path.basename(file_path)}: 只能上传Excel(.xlsx)格式的文件")
                    continue

                # 检查是否已经添加过相同的文件
                if file_path in widget_dict['selected_files']:
                    messagebox.showinfo("提示", f"文件 {os.path.basename(file_path)} 已在列表中")
                    continue

                # 添加到文件列表
                widget_dict['selected_files'].append(file_path)
                files_listbox.insert(tk.END, os.path.basename(file_path))
                print(f"选择的测试用例文件: {file_path}")

            # 更新第一个文件作为主文件（如果还没有设置）
            if widget_dict['selected_files'] and not widget_dict.get('test_case_file'):
                widget_dict['test_case_file'] = widget_dict['selected_files'][0]
        else:
            print("未选择文件")

    def clear_selected_files():
        """
        清空已选择的文件列表
        """
        files_listbox.delete(0, tk.END)
        widget_dict['selected_files'] = []
        if 'test_case_file' in widget_dict:
            del widget_dict['test_case_file']
        print("已清空选择的文件")

    def remove_selected_file():
        """
        从已选择列表中移除选中的文件
        """
        selected_indices = files_listbox.curselection()
        if not selected_indices:
            messagebox.showinfo("提示", "请先选择要移除的文件")
            return

        selected_index = selected_indices[0]
        file_path = widget_dict['selected_files'][selected_index]
        file_name = os.path.basename(file_path)

        # 从列表和数据中移除
        files_listbox.delete(selected_index)
        widget_dict['selected_files'].pop(selected_index)

        # 如果删除的是主文件，需要更新主文件引用
        if widget_dict.get('test_case_file') == file_path:
            if widget_dict['selected_files']:
                widget_dict['test_case_file'] = widget_dict['selected_files'][0]
            else:
                if 'test_case_file' in widget_dict:
                    del widget_dict['test_case_file']

        print(f"已移除文件: {file_name}")

    # 添加文件操作按钮
    upload_button = ttk.Button(file_buttons_frame, text="选择文件", command=upload_files, width=15)
    upload_button.pack(side=tk.LEFT, padx=5)

    remove_button = ttk.Button(file_buttons_frame, text="移除选中", command=remove_selected_file, width=15)
    remove_button.pack(side=tk.LEFT, padx=5)

    clear_button = ttk.Button(file_buttons_frame, text="清空选择", command=clear_selected_files, width=15)
    clear_button.pack(side=tk.LEFT, padx=5)

    # 右侧框架：显示cases_date目录下的xlsx文件列表
    right_frame = ttk.LabelFrame(content_frame, text="已上传的测试用例文件", padding=(10, 5))
    right_frame.pack(side=tk.RIGHT, fill="both", expand=True)

    # 创建一个框架来包含列表和滚动条
    list_frame = ttk.Frame(right_frame)
    list_frame.pack(fill="both", expand=True, pady=5)

    # 创建滚动条
    scrollbar = ttk.Scrollbar(list_frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # 创建列表框显示已上传的文件
    xlsx_files = get_xlsx_files_in_cases_date()
    listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set, height=15)
    listbox.pack(side=tk.LEFT, fill="both", expand=True)

    # 配置滚动条
    scrollbar.config(command=listbox.yview)

    # 填充列表框，显示当前已有的Excel文件
    for file in xlsx_files:
        listbox.insert(tk.END, file)

    widget_dict['listbox'] = listbox

    # 按钮区域 - 右侧文件操作按钮
    right_buttons_frame = ttk.Frame(right_frame)
    right_buttons_frame.pack(fill="x", pady=10)

    # 添加刷新按钮 - 更新右侧已上传文件列表
    def refresh_list():
        """
        刷新右侧文件列表，显示cases_date目录下的最新文件
        """
        listbox.delete(0, tk.END)  # 清空列表
        xlsx_files = get_xlsx_files_in_cases_date()  # 重新获取文件列表
        for file in xlsx_files:
            listbox.insert(tk.END, file)  # 重新填充列表

    refresh_button = ttk.Button(right_buttons_frame, text="刷新列表", command=refresh_list, width=15)
    refresh_button.pack(side=tk.LEFT, padx=5)

    # 右侧添加删除按钮 - 删除已上传的文件
    def delete_selected_file():
        """
        删除选中的已上传文件
        """
        selected_indices = listbox.curselection()
        if not selected_indices:
            messagebox.showinfo("提示", "请先选择要删除的文件")
            return

        selected_index = selected_indices[0]
        file_name = listbox.get(selected_index)
        file_path = os.path.join(home, 'cases_date', file_name)

        try:
            os.remove(file_path)  # 删除文件
            listbox.delete(selected_index)  # 从列表中移除
            messagebox.showinfo("成功", f"文件 {file_name} 已删除")
        except Exception as e:
            messagebox.showerror("错误", f"删除文件失败: {e}")

    delete_button = ttk.Button(right_buttons_frame, text="删除选中", command=delete_selected_file, width=15)
    delete_button.pack(side=tk.LEFT, padx=5)

    # 添加提交按钮区域
    submit_frame = ttk.Frame(main_frame)
    submit_frame.pack(fill="x", pady=20)

    # 上传按钮 - 上传选中的文件
    submit_button = ttk.Button(
        submit_frame,
        text="上传文件",
        command=lambda: submit_files(widget_dict),
        style="Accent.TButton",
        width=15
    )
    submit_button.pack(side=tk.LEFT, padx=10)

    # 取消按钮 - 清空选择
    cancel_button = ttk.Button(
        submit_frame,
        text="取消",
        command=clear_selected_files,
        width=15
    )
    cancel_button.pack(side=tk.LEFT, padx=10)

    return widget_dict


def upload_selected_files(widget_dict):
    """
    上传选中的文件到cases_date目录

    Args:
        widget_dict: 包含控件引用的字典

    Returns:
        list: 成功上传的文件名列表
    """
    selected_files = widget_dict.get('selected_files', [])
    
    # 验证文件是否选择
    if not selected_files:
        messagebox.showwarning("提示", "请选择至少一个测试用例文件")
        return []

    # 确保cases_date目录存在
    cases_date_dir = os.path.join(home, 'cases_date')
    os.makedirs(cases_date_dir, exist_ok=True)

    # 复制所有选中的文件到cases_date目录
    copied_files = []
    for file_path in selected_files:
        # 获取文件名
        file_name = os.path.basename(file_path)
        # 构建目标文件路径
        target_file_path = os.path.join(cases_date_dir, file_name)
        try:
            # 复制文件
            shutil.copy2(file_path, target_file_path)
            copied_files.append(file_name)
            print(f"文件已成功复制到: {target_file_path}")
        except Exception as e:
            error_msg = f"复制文件时出错: {e}"
            print(error_msg)
            messagebox.showerror("错误", error_msg)

    # 如果有文件成功复制，则更新状态
    if copied_files:
        # 更新文件列表显示
        listbox = widget_dict['listbox']
        listbox.delete(0, tk.END)
        xlsx_files = get_xlsx_files_in_cases_date()
        for file in xlsx_files:
            listbox.insert(tk.END, file)
            
        messagebox.showinfo("成功", f"已成功上传 {len(copied_files)} 个文件")
    else:
        messagebox.showwarning("提示", "没有文件被上传")
        
    return copied_files


def submit_files(widget_dict):
    """
    处理文件管理页面的提交按钮点击事件

    Args:
        widget_dict: 包含控件引用的字典
    """
    # 上传选中的文件
    uploaded_files = upload_selected_files(widget_dict)
    
    # 如果上传成功，清空选择列表
    if uploaded_files:
        files_listbox = widget_dict['files_listbox']
        files_listbox.delete(0, tk.END)
        widget_dict['selected_files'] = []
        if 'test_case_file' in widget_dict:
            del widget_dict['test_case_file'] 