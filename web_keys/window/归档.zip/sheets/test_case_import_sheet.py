"""
测试用例导入sheet页

该模块提供了一个图形用户界面，用于查看已上传的测试用例文件和目录，包括：
1. 显示已上传的测试用例文件
2. 显示目录结构
3. 导入测试用例功能
"""

import tkinter as tk
from tkinter import ttk, messagebox
import os
import json
from web_keys.environment_info.montage_url import home



def get_xlsx_files_in_cases_date():
    """
    获取cases_date目录下所有的xlsx文件

    Returns:
        list: xlsx文件列表，如果目录不存在会先创建
    """
    cases_date_dir = os.path.join(home, 'cases_date')
    if not os.path.exists(cases_date_dir):
        os.makedirs(cases_date_dir, exist_ok=True)
        return []

    files = os.listdir(cases_date_dir)
    xlsx_files = [f for f in files if f.lower().endswith('.xlsx')]
    return xlsx_files


def get_directories_in_path(path):
    """
    获取指定路径下的所有目录

    Args:
        path: 目录路径

    Returns:
        list: 目录列表，如果路径不存在返回空列表
    """
    if not os.path.exists(path):
        return []

    try:
        items = os.listdir(path)
        directories = [item for item in items if os.path.isdir(os.path.join(path, item))]
        return sorted(directories)
    except Exception as e:
        print(f"获取目录列表出错: {e}")
        return []


def get_py_files_in_directory(directory):
    """
    获取指定目录下所有的py文件

    Args:
        directory: 目录路径

    Returns:
        list: py文件列表，如果目录不存在返回空列表
    """
    if not os.path.exists(directory):
        return []

    try:
        files = os.listdir(directory)
        py_files = [f for f in files if f.lower().endswith('.py')]
        return sorted(py_files)
    except Exception as e:
        print(f"获取py文件列表出错: {e}")
        return []


def get_config_path():
    """
    获取配置文件路径

    Returns:
        str: 配置文件路径
    """
    config_dir = os.path.join(home, 'config')
    if not os.path.exists(config_dir):
        os.makedirs(config_dir, exist_ok=True)
    
    return os.path.join(config_dir, 'directory_config.json')


def load_directory_config():
    """
    加载目录配置

    Returns:
        str: 配置的目录路径，默认为home目录
    """
    config_path = get_config_path()
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                return config.get('directory_path', home)
        except Exception as e:
            print(f"加载目录配置出错: {e}")
    
    return home


def save_directory_config(directory_path):
    """
    保存目录配置

    Args:
        directory_path: 要保存的目录路径
    """
    config_path = get_config_path()
    try:
        with open(config_path, 'w') as f:
            json.dump({'directory_path': directory_path}, f)
        return True
    except Exception as e:
        print(f"保存目录配置出错: {e}")
        return False


def create_test_case_import_sheet(parent_frame, widget_dict):
    """
    创建测试用例导入sheet页

    Args:
        parent_frame: 父框架对象
        widget_dict: 用于存储控件引用的字典

    Returns:
        dict: 更新后的widget_dict
    """
    # 创建主框架
    main_frame = ttk.Frame(parent_frame, padding="20")
    main_frame.pack(fill=tk.BOTH, expand=True)

    # 创建标题
    title_label = ttk.Label(main_frame, text="测试用例导入", font=("Arial", 16, "bold"))
    title_label.pack(anchor="center", pady=(0, 20))

    # 创建左右两栏框架
    content_frame = ttk.Frame(main_frame)
    content_frame.pack(fill="both", expand=True)

    # 左侧框架：已上传的测试用例文件
    left_frame = ttk.LabelFrame(content_frame, text="已上传的测试用例文件", padding=(10, 5))
    left_frame.pack(side=tk.LEFT, fill="both", expand=True, padx=(0, 10))

    # 创建列表框显示已上传的测试用例文件
    files_list_frame = ttk.Frame(left_frame)
    files_list_frame.pack(fill="both", expand=True, pady=5)

    files_scrollbar = ttk.Scrollbar(files_list_frame)
    files_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # 设置多选模式
    files_listbox = tk.Listbox(files_list_frame, yscrollcommand=files_scrollbar.set, height=15, selectmode=tk.MULTIPLE)
    files_listbox.pack(side=tk.LEFT, fill="both", expand=True)
    files_scrollbar.config(command=files_listbox.yview)

    # 填充列表框，显示当前已有的Excel文件
    xlsx_files = get_xlsx_files_in_cases_date()
    for file in xlsx_files:
        files_listbox.insert(tk.END, file)

    widget_dict['import_files_listbox'] = files_listbox

    # 按钮区域 - 左侧文件操作按钮
    left_buttons_frame = ttk.Frame(left_frame)
    left_buttons_frame.pack(fill="x", pady=10)

    # 添加刷新按钮
    def refresh_files_list():
        """
        刷新文件列表，显示cases_date目录下的最新文件
        """
        files_listbox.delete(0, tk.END)  # 清空列表
        xlsx_files = get_xlsx_files_in_cases_date()  # 重新获取文件列表
        for file in xlsx_files:
            files_listbox.insert(tk.END, file)  # 重新填充列表

    refresh_button = ttk.Button(left_buttons_frame, text="刷新列表", command=refresh_files_list, width=15)
    refresh_button.pack(side=tk.LEFT, padx=5)

    # 导入测试用例按钮
    def import_test_case():
        """
        导入测试用例功能（暂定）
        """
        selected_indices = files_listbox.curselection()
        if not selected_indices:
            messagebox.showinfo("提示", "请先选择要导入的测试用例文件")
            return
        
        selected_files = [files_listbox.get(i) for i in selected_indices]
        messagebox.showinfo("提示", f"已选择 {len(selected_files)} 个文件，导入测试用例功能暂未实现，后续开发")

    import_button = ttk.Button(left_buttons_frame, text="导入测试用例", command=import_test_case, width=15)
    import_button.pack(side=tk.LEFT, padx=5)

    # 右侧框架：目录显示
    right_frame = ttk.LabelFrame(content_frame, text="目录", padding=(10, 5))
    right_frame.pack(side=tk.RIGHT, fill="both", expand=True)

    # 创建上下两部分
    # 上部：目录树
    dir_tree_frame = ttk.LabelFrame(right_frame, text="目录结构", padding=(5, 5))
    dir_tree_frame.pack(fill="both", expand=True, pady=(0, 5))

    # 创建目录树
    dir_tree_scrollbar = ttk.Scrollbar(dir_tree_frame)
    dir_tree_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    dir_tree = ttk.Treeview(dir_tree_frame, yscrollcommand=dir_tree_scrollbar.set, height=8)
    dir_tree.pack(side=tk.LEFT, fill="both", expand=True)
    dir_tree_scrollbar.config(command=dir_tree.yview)

    # 配置目录树
    dir_tree["columns"] = ("path")
    dir_tree.column("#0", width=200, minwidth=200)
    dir_tree.column("path", width=0, stretch=tk.NO)  # 隐藏路径列
    dir_tree.heading("#0", text="目录名")
    dir_tree.heading("path", text="路径")

    # 存储当前路径
    current_path = [home]  # 使用列表存储，以便在函数内部修改

    # 填充目录树
    def populate_dir_tree(path):
        """
        填充目录树

        Args:
            path: 要显示的目录路径
        """
        # 清空目录树
        for item in dir_tree.get_children():
            dir_tree.delete(item)

        # 获取目录列表
        directories = get_directories_in_path(path)

        # 添加目录到树中
        for directory in directories:
            full_path = os.path.join(path, directory)
            dir_tree.insert("", "end", text=directory, values=(full_path,))

    # 初始填充目录树
    populate_dir_tree(home)

    # 目录树点击事件
    def on_dir_tree_select(event):
        """
        处理目录树选择事件
        """
        selected_items = dir_tree.selection()
        if not selected_items:
            return

        item = selected_items[0]
        path = dir_tree.item(item, "values")[0]
        current_path[0] = path

        # 更新目录树
        populate_dir_tree(path)

        # 更新文件列表
        refresh_file_list(path)

    dir_tree.bind("<<TreeviewSelect>>", on_dir_tree_select)

    # 回到默认路径按钮
    def go_to_home():
        """
        回到默认路径
        """
        current_path[0] = home
        populate_dir_tree(home)
        refresh_file_list(home)

    home_button = ttk.Button(dir_tree_frame, text="回到默认路径", command=go_to_home, width=15)
    home_button.pack(side=tk.BOTTOM, pady=5)

    # 下部：文件列表
    file_list_frame = ttk.LabelFrame(right_frame, text="Python文件", padding=(5, 5))
    file_list_frame.pack(fill="both", expand=True)

    file_list_scrollbar = ttk.Scrollbar(file_list_frame)
    file_list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    file_listbox = tk.Listbox(file_list_frame, yscrollcommand=file_list_scrollbar.set, height=8)
    file_listbox.pack(side=tk.LEFT, fill="both", expand=True)
    file_list_scrollbar.config(command=file_listbox.yview)

    widget_dict['directory_listbox'] = file_listbox

    # 刷新文件列表
    def refresh_file_list(path):
        """
        刷新文件列表，显示当前目录下的py文件

        Args:
            path: 目录路径
        """
        file_listbox.delete(0, tk.END)  # 清空列表

        # 获取py文件
        py_files = get_py_files_in_directory(path)
        
        # 如果没有py文件，显示子目录
        if not py_files:
            directories = get_directories_in_path(path)
            for directory in directories:
                file_listbox.insert(tk.END, f"[目录] {directory}")
        else:
            # 显示py文件
            for file in py_files:
                file_listbox.insert(tk.END, file)

    # 初始填充文件列表
    refresh_file_list(home)

    # 文件列表点击事件
    def on_file_list_select(event):
        """
        处理文件列表选择事件
        """
        selected_indices = file_listbox.curselection()
        if not selected_indices:
            return

        selected_item = file_listbox.get(selected_indices[0])
        
        # 如果是目录，则进入该目录
        if selected_item.startswith("[目录]"):
            directory = selected_item[5:].strip()  # 去掉"[目录] "前缀
            new_path = os.path.join(current_path[0], directory)
            current_path[0] = new_path
            populate_dir_tree(new_path)
            refresh_file_list(new_path)

    file_listbox.bind("<<ListboxSelect>>", on_file_list_select)

    return widget_dict 